/* Ajouter/retirer des lignes sans bibliothèque de formulaire supplémentaire.
 * Le serveur revalide chaque champ ; les droits et le nonce restent gérés par WP.
 */
(() => {
  const list = document.querySelector("#lb-items");
  if (!list) return;
  let nextIndex = list.children.length;
  document.querySelector("#lb-add-item").addEventListener("click", () => {
    const fragment = document
      .querySelector("#lb-item-template")
      .content.cloneNode(true);
    fragment.querySelectorAll("[name]").forEach((input) => {
      input.name = input.name.replace("[9999]", `[${nextIndex}]`);
    });
    nextIndex += 1;
    fragment.querySelector(".lb-item-number").textContent = nextIndex;
    list.append(fragment);
    list.lastElementChild.querySelector("input").focus();
  });
  list.addEventListener("click", (event) => {
    const button = event.target.closest(".lb-remove-item");
    if (!button) return;
    if (
      !confirm(
        "Retirer cette pizza ? La suppression sera appliquée après enregistrement.",
      )
    )
      return;
    button.closest(".lb-menu-item").remove();
    document.querySelector("#lb-add-item").focus();
  });
  const status = document.querySelector("#lb-photo-status");
  document.querySelector("#lb-select-photo").addEventListener("click", () => {
    const frame = wp.media({
      title: "Choisir une photo",
      button: { text: "Utiliser cette photo" },
      library: { type: "image" },
      multiple: false,
    });
    frame.on("select", () => {
      document.querySelector("#lb-photo-id").value = frame
        .state()
        .get("selection")
        .first().id;
      status.textContent = "Photo sélectionnée. Enregistrez pour la publier.";
    });
    frame.open();
  });
  document.querySelector("#lb-reset-photo").addEventListener("click", () => {
    document.querySelector("#lb-photo-id").value = "0";
    status.textContent =
      "Photo d’illustration rétablie. Enregistrez pour appliquer.";
  });
})();
