<?php
if (!defined("ABSPATH")) {
    exit();
}
add_action("after_setup_theme", function () {
    add_theme_support("title-tag");
    add_theme_support("post-thumbnails");
});
add_action("wp_enqueue_scripts", function () {
    wp_enqueue_style(
        "lb-pizza",
        get_template_directory_uri() . "/assets/site.css",
        [],
        "1.0.0",
    );
    wp_enqueue_script(
        "lb-pizza",
        get_template_directory_uri() . "/assets/site.js",
        [],
        "1.0.0",
        true,
    );
});
// La démonstration ne collecte pas de messages et n’a pas de parcours de commande.
add_filter("wp_robots", function ($robots) {
    $robots["noindex"] = true;
    $robots["nofollow"] = true;
    return $robots;
});
