<?php
/**
 * Plugin Name: Carte Pizzeria — démonstration Lucas Berdy
 * Description: Une carte, deux tailles, les horaires et une annonce modifiables sans toucher au code.
 * Version: 1.0.0
 * Author: Lucas Berdy
 */
if (!defined("ABSPATH")) {
    exit();
}

/** Les valeurs initiales sont fictives : aucune carte commerciale réelle n’est reproduite. */
function lb_pizzeria_defaults()
{
    return [
        "name" => "Atelier Pizza",
        "tagline" => "La bonne pizza. Tout simplement.",
        "intro" =>
            "Une carte facile à parcourir, des recettes qui donnent envie et toutes les informations au même endroit.",
        "announcement" => "",
        "photo_id" => 0,
        "hours" => [
            "Lundi" => "Fermé",
            "Mardi" => "18h00 – 21h30",
            "Mercredi" => "18h00 – 21h30",
            "Jeudi" => "18h00 – 21h30",
            "Vendredi" => "18h00 – 22h00",
            "Samedi" => "18h00 – 22h00",
            "Dimanche" => "18h00 – 21h30",
        ],
        "items" => [
            [
                "name" => "Margherita",
                "description" => "Tomate, mozzarella, basilic.",
                "category" => "Les classiques",
                "small" => 950,
                "large" => 1150,
                "visible" => 1,
            ],
            [
                "name" => "La Reine",
                "description" => "Tomate, mozzarella, jambon, champignons.",
                "category" => "Les classiques",
                "small" => 1150,
                "large" => 1350,
                "visible" => 1,
            ],
            [
                "name" => "Quatre fromages",
                "description" => "Crème, mozzarella, chèvre, bleu, emmental.",
                "category" => "Les gourmandes",
                "small" => 1250,
                "large" => 1450,
                "visible" => 1,
            ],
            [
                "name" => "La Montagnarde",
                "description" =>
                    "Crème, mozzarella, pommes de terre, fromage à raclette.",
                "category" => "Les gourmandes",
                "small" => 1300,
                "large" => 1500,
                "visible" => 1,
            ],
            [
                "name" => "La Méditerranéenne",
                "description" =>
                    "Tomate, mozzarella, courgettes, poivrons, olives.",
                "category" => "Les végétariennes",
                "small" => 1150,
                "large" => 1350,
                "visible" => 1,
            ],
            [
                "name" => "La Champignon",
                "description" => "Crème, mozzarella, champignons, roquette.",
                "category" => "Les végétariennes",
                "small" => 1200,
                "large" => 1400,
                "visible" => 1,
            ],
        ],
    ];
}
function lb_pizzeria_data()
{
    return wp_parse_args(get_option("lb_pizzeria", []), lb_pizzeria_defaults());
}
function lb_pizzeria_activate()
{
    add_option("lb_pizzeria", lb_pizzeria_defaults());
    add_role("pizzeria_manager", "Responsable de la carte", [
        "read" => true,
        "edit_pizzeria_menu" => true,
        "upload_files" => true,
    ]);
    $admin = get_role("administrator");
    if ($admin) {
        $admin->add_cap("edit_pizzeria_menu");
    }
}
register_activation_hook(__FILE__, "lb_pizzeria_activate");

/** Validation serveur : listes autorisées, prix en centimes et échappement à l’affichage.
 * L’API Settings de WordPress vérifie les droits et le nonce avant chaque sauvegarde.
 */
function lb_pizzeria_sanitize($input)
{
    $old = lb_pizzeria_data();
    $output = $old;
    foreach (["name", "tagline", "intro", "announcement"] as $key) {
        $output[$key] = sanitize_text_field(
            isset($input[$key]) ? $input[$key] : "",
        );
    }
    if ($output["name"] === "") {
        $output["name"] = $old["name"];
    }
    $output["photo_id"] = absint(
        isset($input["photo_id"]) ? $input["photo_id"] : 0,
    );
    if ($output["photo_id"] && !wp_attachment_is_image($output["photo_id"])) {
        $output["photo_id"] = 0;
    }
    foreach (array_keys(lb_pizzeria_defaults()["hours"]) as $day) {
        $output["hours"][$day] = sanitize_text_field(
            isset($input["hours"][$day]) ? $input["hours"][$day] : "Fermé",
        );
    }
    $output["items"] = [];
    $categories = ["Les classiques", "Les gourmandes", "Les végétariennes"];
    foreach (
        array_slice(
            isset($input["items"]) && is_array($input["items"])
                ? $input["items"]
                : [],
            0,
            50,
        )
        as $item
    ) {
        $name = sanitize_text_field(isset($item["name"]) ? $item["name"] : "");
        if ($name === "") {
            continue;
        }
        $row = [
            "name" => $name,
            "description" => sanitize_text_field(
                isset($item["description"]) ? $item["description"] : "",
            ),
            "category" => in_array(
                isset($item["category"]) ? $item["category"] : "",
                $categories,
                true,
            )
                ? $item["category"]
                : $categories[0],
            "visible" => !empty($item["visible"]) ? 1 : 0,
        ];
        foreach (["small", "large"] as $size) {
            $price = str_replace(
                ",",
                ".",
                isset($item[$size]) ? (string) $item[$size] : "0",
            );
            $row[$size] = max(0, min(99900, (int) round((float) $price * 100)));
        }
        $output["items"][] = $row;
    }
    return $output;
}
add_action("admin_init", function () {
    register_setting("lb_pizzeria_group", "lb_pizzeria", [
        "sanitize_callback" => "lb_pizzeria_sanitize",
    ]);
});
add_filter("option_page_capability_lb_pizzeria_group", function () {
    return "edit_pizzeria_menu";
});
add_action("admin_menu", function () {
    add_menu_page(
        "Carte et horaires",
        "Carte et horaires",
        "edit_pizzeria_menu",
        "lb-pizzeria",
        "lb_pizzeria_admin",
        "dashicons-food",
        3,
    );
});
add_action("admin_enqueue_scripts", function ($hook) {
    if ($hook !== "toplevel_page_lb-pizzeria") {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_style(
        "lb-pizzeria-admin",
        plugins_url("admin.css", __FILE__),
        [],
        "1.0.0",
    );
    wp_enqueue_script(
        "lb-pizzeria-admin",
        plugins_url("admin.js", __FILE__),
        ["jquery"],
        "1.0.0",
        true,
    );
});

function lb_pizzeria_row($item, $index)
{
    $prefix = "lb_pizzeria[items][" . $index . "]"; ?>
    <fieldset class="lb-menu-item">
        <legend>Pizza <span class="lb-item-number"><?php echo esc_html(
            (string) ($index + 1),
        ); ?></span></legend>
        <div class="lb-item-grid">
            <label>Nom<input name="<?php echo esc_attr(
                $prefix,
            ); ?>[name]" value="<?php echo esc_attr($item["name"]); ?>" maxlength="80" required></label>
            <label>Catégorie<select name="<?php echo esc_attr(
                $prefix,
            ); ?>[category]">
                <?php foreach (
                    ["Les classiques", "Les gourmandes", "Les végétariennes"]
                    as $category
                ) { ?><option <?php selected(
    $item["category"],
    $category,
); ?>><?php echo esc_html($category); ?></option><?php } ?>
            </select></label>
            <label>Prix 29 cm (€)<input type="number" step="0.01" min="0" max="999" name="<?php echo esc_attr(
                $prefix,
            ); ?>[small]" value="<?php echo esc_attr(number_format($item["small"] / 100, 2, ".", "")); ?>" required></label>
            <label>Prix 33 cm (€)<input type="number" step="0.01" min="0" max="999" name="<?php echo esc_attr(
                $prefix,
            ); ?>[large]" value="<?php echo esc_attr(number_format($item["large"] / 100, 2, ".", "")); ?>" required></label>
        </div>
        <label>Ingrédients / description<input class="widefat" name="<?php echo esc_attr(
            $prefix,
        ); ?>[description]" value="<?php echo esc_attr($item["description"]); ?>" maxlength="250"></label>
        <div class="lb-item-actions"><label><input type="checkbox" name="<?php echo esc_attr(
            $prefix,
        ); ?>[visible]" value="1" <?php checked(!empty($item["visible"])); ?>> Visible sur la carte</label><button type="button" class="button lb-remove-item">Retirer cette pizza</button></div>
    </fieldset>
    <?php
}
function lb_pizzeria_admin()
{
    if (!current_user_can("edit_pizzeria_menu")) {
        return;
    }
    $data = lb_pizzeria_data();
    ?>
    <div class="wrap lb-admin">
        <h1>Votre carte, vos horaires.</h1>
        <p class="lb-admin-lead">Modifiez vos informations, puis enregistrez. Le site se met à jour sans toucher à sa mise en page.</p>
        <div class="notice notice-info"><p><strong>Démonstration indépendante.</strong> Établissement, recettes, horaires et prix fictifs. Aucun service de commande ni de paiement n’est connecté.</p></div>
        <?php settings_errors("lb_pizzeria"); ?>
        <p><a class="button" href="<?php echo esc_url(
            home_url("/"),
        ); ?>" target="_blank" rel="noopener">Voir la carte dans un nouvel onglet</a></p>
        <form action="options.php" method="post">
            <?php settings_fields("lb_pizzeria_group"); ?>
            <section class="lb-panel"><h2>Présentation</h2>
                <?php foreach (
                    [
                        "name" => "Nom de l’établissement",
                        "tagline" => "Titre de présentation",
                        "intro" => "Texte de présentation",
                    ]
                    as $key => $label
                ) { ?><label><?php echo esc_html(
    $label,
); ?><input class="widefat" name="lb_pizzeria[<?php echo esc_attr(
    $key,
); ?>]" value="<?php echo esc_attr(
    $data[$key],
); ?>" maxlength="<?php echo $key === "intro"
    ? "300"
    : "100"; ?>" <?php echo $key === "name"
    ? "required"
    : ""; ?>></label><?php } ?>
                <label>Annonce ponctuelle<input class="widefat" name="lb_pizzeria[announcement]" value="<?php echo esc_attr(
                    $data["announcement"],
                ); ?>" maxlength="200" placeholder="Exemple : fermeture exceptionnelle mardi soir"></label>
                <p class="description">Laisser vide pour masquer le bandeau d’annonce.</p>
                <input id="lb-photo-id" type="hidden" name="lb_pizzeria[photo_id]" value="<?php echo esc_attr(
                    (string) $data["photo_id"],
                ); ?>">
                <div class="lb-photo-actions"><button class="button" type="button" id="lb-select-photo">Choisir une photo</button><button class="button" type="button" id="lb-reset-photo">Revenir à la photo d’illustration</button><span id="lb-photo-status" role="status"><?php echo $data[
                    "photo_id"
                ]
                    ? "Photo personnalisée sélectionnée."
                    : "Photo d’illustration utilisée."; ?></span></div>
            </section>
            <section class="lb-panel"><h2>La carte</h2><p>Deux tailles par pizza. Décochez « Visible » pour masquer temporairement un produit.</p>
                <div id="lb-items"><?php foreach (
                    $data["items"]
                    as $i => $item
                ) {
                    lb_pizzeria_row($item, $i);
                } ?></div>
                <button class="button" type="button" id="lb-add-item">Ajouter une pizza</button>
            </section>
            <section class="lb-panel"><h2>Horaires</h2><p>Indiquez vos créneaux ou « Fermé ». Les changements sont visibles après enregistrement.</p><div class="lb-hours-grid">
                <?php foreach (
                    $data["hours"]
                    as $day => $hours
                ) { ?><label><?php echo esc_html(
    $day,
); ?><input name="lb_pizzeria[hours][<?php echo esc_attr(
    $day,
); ?>]" value="<?php echo esc_attr(
    $hours,
); ?>" maxlength="100"></label><?php } ?>
            </div></section>
            <div class="lb-save-bar"><?php submit_button(
                "Enregistrer les modifications",
                "primary",
                "submit",
                false,
            ); ?><span>Les modifications concernent cette démonstration uniquement.</span></div>
        </form>
        <template id="lb-item-template"><?php lb_pizzeria_row(
            [
                "name" => "",
                "description" => "",
                "category" => "Les classiques",
                "small" => 0,
                "large" => 0,
                "visible" => 1,
            ],
            9999,
        ); ?></template>
    </div>
    <?php
}
