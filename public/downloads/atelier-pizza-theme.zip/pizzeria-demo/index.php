<?php
if (!defined("ABSPATH")) {
    exit();
}
if (!function_exists("lb_pizzeria_data")) {
    wp_die(
        "Activez le plugin Carte Pizzeria pour utiliser cette démonstration.",
    );
}
$data = lb_pizzeria_data();
$photo = $data["photo_id"]
    ? wp_get_attachment_image_url($data["photo_id"], "large")
    : get_template_directory_uri() . "/assets/pizza-illustration.webp";
$items = array_values(
    array_filter($data["items"], function ($item) {
        return !empty($item["visible"]);
    }),
);
$categories = array_values(array_unique(array_column($items, "category")));
function lb_pizza_price($cents)
{
    return number_format($cents / 100, 2, ",", " ") . " €";
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo(
    "charset",
); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="description" content="Démonstration indépendante : une carte de pizzeria modifiable dans WordPress. Établissement et données fictifs."><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main">Aller au contenu</a>
<div class="demo-note"><span>PROTOTYPE INDÉPENDANT</span> Établissement, carte et horaires fictifs. Aucune commande possible.</div>
<header class="site-header shell">
    <a class="brand" href="#top" aria-label="<?php echo esc_attr(
        $data["name"],
    ); ?> — accueil"><span class="brand-symbol" aria-hidden="true">a.</span><span><?php echo esc_html(
     $data["name"],
 ); ?><small>LA PIZZERIA · DÉMONSTRATION</small></span></a>
    <nav aria-label="Navigation principale"><a href="#carte">La carte</a><a href="#infos">Les infos</a><a class="button small" href="<?php echo esc_url(
        admin_url("admin.php?page=lb-pizzeria"),
    ); ?>">Modifier la carte <svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 19 19 5M5 5h14v14" /></svg></a></nav>
</header>
<main id="main">
<?php if (
    $data["announcement"] !== ""
) { ?><div class="announcement shell" role="status"><?php echo esc_html(
    $data["announcement"],
); ?></div><?php } ?>
<section class="hero shell" id="top">
    <div class="hero-copy"><p class="eyebrow">LE GOÛT DES CHOSES SIMPLES</p><h1><?php echo esc_html(
        $data["tagline"],
    ); ?></h1><p class="hero-lead"><?php echo esc_html(
    $data["intro"],
); ?></p><a class="button" href="#carte">Trouver ma pizza <svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 5l14 14M5 19h14V5" /></svg></a><div class="hero-meta"><span>Deux tailles.<br><strong>À vous de choisir.</strong></span><span>Une carte claire.<br><strong>Même sur téléphone.</strong></span></div></div>
    <figure class="hero-photo"><img src="<?php echo esc_url(
        $photo,
    ); ?>" alt="Pizza photographiée pour illustrer cette démonstration" width="1000" height="1000" fetchpriority="high"><figcaption>Visuel d’illustration · ne représente pas le commerce prospecté.</figcaption><span class="photo-label" aria-hidden="true">À PARTAGER.<br>OU PAS.</span></figure>
</section>
<div class="section-line shell"><span>UNE ENVIE, UNE PIZZA.</span><span>01 — LA CARTE</span></div>
<section class="menu-section shell" id="carte" aria-labelledby="menu-title">
    <div class="section-heading reveal"><div><p class="eyebrow">CHOISISSEZ VOTRE FAVORITE</p><h2 id="menu-title">La carte.<br><em>Simplement.</em></h2></div><p>Des catégories lisibles, les ingrédients et les prix au même endroit. Les recettes et les prix ci-dessous sont des exemples fictifs.</p></div>
    <div class="menu-toolbar"><div class="category-filters" aria-label="Filtrer la carte"><button data-filter="all" aria-pressed="true">Toutes les pizzas</button><?php foreach (
        $categories
        as $category
    ) { ?><button data-filter="<?php echo esc_attr(
    $category,
); ?>" aria-pressed="false"><?php echo esc_html(
    $category,
); ?></button><?php } ?></div><span class="sizes-note">29 cm / 33 cm</span></div>
    <p class="sr-only" id="filter-status" role="status"></p>
    <div class="pizza-grid"><?php foreach ($items as $index => $item) { ?>
        <article class="pizza-card reveal" data-category="<?php echo esc_attr(
            $item["category"],
        ); ?>"><div class="pizza-card-top"><span class="pizza-number" aria-hidden="true"><?php echo esc_html(
    str_pad((string) ($index + 1), 2, "0", STR_PAD_LEFT),
); ?></span><span class="pizza-category"><?php echo esc_html(
    $item["category"],
); ?></span></div><h3><?php echo esc_html(
    $item["name"],
); ?></h3><p><?php echo esc_html(
    $item["description"],
); ?></p><dl class="pizza-prices"><div><dt>29 cm</dt><dd><?php echo esc_html(
    lb_pizza_price($item["small"]),
); ?></dd></div><div><dt>33 cm</dt><dd><?php echo esc_html(
    lb_pizza_price($item["large"]),
); ?></dd></div></dl></article>
    <?php } ?></div>
    <?php if (
        !$items
    ) { ?><p>La carte est en cours de mise à jour.</p><?php } ?>
    <p class="menu-footnote">Carte fictive de démonstration. Les informations alimentaires et les prix d’un futur site devront être validés avec le professionnel.</p>
</section>
<section class="owner-story" aria-labelledby="owner-title"><div class="shell owner-grid"><div class="reveal"><p class="eyebrow">CÔTÉ RESTAURATEUR</p><h2 id="owner-title">Votre carte change.<br><em>Votre site suit.</em></h2></div><div class="owner-copy reveal"><p>Un nouveau prix, une pizza momentanément indisponible ou une fermeture exceptionnelle : modifiez les champs dans votre espace WordPress, puis enregistrez.</p><p>La présentation reste cohérente. Aucun code à modifier, aucune nouvelle mise en ligne à demander pour ces contenus.</p><a class="button light" href="<?php echo esc_url(
    admin_url("admin.php?page=lb-pizzeria"),
); ?>">Essayer l’édition de la carte <svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M5 19 19 5M5 5h14v14" /></svg></a><small>Accès local de démonstration · identifiants fournis séparément.</small></div></div></section>
<section class="info-section shell" id="infos" aria-labelledby="info-title"><div class="section-heading reveal"><div><p class="eyebrow">LES INFOS PRATIQUES</p><h2 id="info-title">On se retrouve<br><em>quand ?</em></h2></div><p>Ces horaires sont fictifs et servent à tester les modifications depuis l’administration.</p></div><div class="info-grid"><div class="hours-card reveal"><h3>Les horaires</h3><dl><?php foreach (
    $data["hours"]
    as $day => $hours
) { ?><div><dt><?php echo esc_html($day); ?></dt><dd><?php echo esc_html(
    $hours,
); ?></dd></div><?php } ?></dl></div><div class="contact-card reveal"><span class="eyebrow">UNE DÉMO À IMAGINER ENSEMBLE</span><h3>Votre adresse.<br>Votre numéro.<br>Vos clients.</h3><p>Un futur site peut réunir les informations utiles et proposer un appel ou un itinéraire. Cette démonstration ne représente aucun commerce et ne reçoit aucune commande.</p><a class="text-link" href="#carte">Revenir à la carte <svg aria-hidden="true" viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M12 20V4m-7 7 7-7 7 7" /></svg></a></div></div></section>
</main>
<footer class="site-footer shell"><span><?php echo esc_html(
    $data["name"],
); ?> · Concept de démonstration</span><span>Conçu par Lucas Berdy · Visuel d’illustration Unsplash</span><a href="<?php echo esc_url(
     admin_url("admin.php?page=lb-pizzeria"),
 ); ?>">Administration WordPress</a></footer>
<?php wp_footer(); ?>
</body></html>
