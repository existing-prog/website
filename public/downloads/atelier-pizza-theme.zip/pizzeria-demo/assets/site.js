/* Filtrer les produits ne modifie jamais la carte enregistrée. Les vraies mises
 * à jour passent par WordPress et restent disponibles après rechargement.
 */
(() => {
  const filters = document.querySelectorAll("[data-filter]");
  const cards = document.querySelectorAll(".pizza-card");
  filters.forEach((button) =>
    button.addEventListener("click", () => {
      const category = button.dataset.filter;
      filters.forEach((item) =>
        item.setAttribute("aria-pressed", String(item === button)),
      );
      let visible = 0;
      cards.forEach((card) => {
        card.hidden = category !== "all" && card.dataset.category !== category;
        if (!card.hidden) {
          visible += 1;
          card.classList.remove("pending");
          card.classList.add("seen");
        }
      });
      document.querySelector("#filter-status").textContent =
        `${visible} pizza${visible > 1 ? "s" : ""} affichée${visible > 1 ? "s" : ""}.`;
    }),
  );
  const reduced = matchMedia("(prefers-reduced-motion: reduce)");
  if (reduced.matches || !("IntersectionObserver" in window)) return;
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        entry.target.classList.remove("pending");
        entry.target.classList.add("seen");
        observer.unobserve(entry.target);
      });
    },
    { threshold: 0.08 },
  );
  document.querySelectorAll(".reveal").forEach((item) => {
    item.classList.add("pending");
    observer.observe(item);
  });
  reduced.addEventListener("change", () => {
    if (!reduced.matches) return;
    observer.disconnect();
    document
      .querySelectorAll(".reveal")
      .forEach((item) => item.classList.remove("pending"));
  });
})();
